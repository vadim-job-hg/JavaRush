package com.javarush.task.task01.task0138;

/* 
Любимое стихотворение
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("Мое любимое стихотворение:");
        System.out.println("нет");
        System.out.println("у меня");
        System.out.println("любимого");
        System.out.println("стихотворения");
        //напишите тут ваш код
    }
}