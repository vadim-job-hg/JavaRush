package com.javarush.task.task01.task0135;

/* 
Белеет парус одинокий
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("Белеет парус одинокий");
        System.out.println("В тумане моря голубом!...");
        System.out.println("Что ищет он в стране далекой?");
        System.out.println("Что кинул он в краю родном?...");

        //напишите тут ваш код
    }
}