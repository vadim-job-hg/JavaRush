package com.javarush.task.task01.task0139;

/* 
Лучше поздно, чем никогда: hello world!
*/

public class Solution {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}