package com.javarush.task.task38.task3804;

public enum ExceptionUserMessage {
    USER_DOES_NOT_EXIST,
    USER_DOES_NOT_HAVE_PERMISSIONS
}
