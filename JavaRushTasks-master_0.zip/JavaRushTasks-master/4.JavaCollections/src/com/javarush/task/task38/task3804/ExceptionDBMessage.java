package com.javarush.task.task38.task3804;

public enum ExceptionDBMessage {
    NOT_ENOUGH_CONNECTIONS,
    RESULT_HAS_NOT_GOTTEN_BECAUSE_OF_TIMEOUT
}
