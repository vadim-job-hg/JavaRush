package com.javarush.task.task36.task3606.data.second;

import com.javarush.task.task36.task3606.HiddenClass;

public class HiddenClassImplFirst implements HiddenClass {
}
