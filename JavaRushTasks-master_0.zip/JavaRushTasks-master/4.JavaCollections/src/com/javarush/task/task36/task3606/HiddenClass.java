package com.javarush.task.task36.task3606;

public interface HiddenClass {
}
