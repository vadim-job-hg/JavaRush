package com.javarush.task.task36.task3606.data.second;

import com.javarush.task.task36.task3606.HiddenClass;

class PackageAccessClass implements HiddenClass {
    PackageAccessClass() {
    }
}
