package com.javarush.task.task29.task2912;

public class Level {
    public static final int INFO = 100;
    public static final int WARN = 200;
    public static final int ERROR = 300;
    public static final int FATAL = 400;
}