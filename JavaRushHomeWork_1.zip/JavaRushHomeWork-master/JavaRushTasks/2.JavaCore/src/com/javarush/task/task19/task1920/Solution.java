package com.javarush.task.task19.task1920;

/* 
Самый богатый
*/

public class Solution {
    public static void main(String[] args) {
    }
}
