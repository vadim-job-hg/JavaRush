package com.javarush.task.task19.task1927;

/* 
Контекстная реклама
*/

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class Solution {
    public static TestString testString = new TestString();

    public static void main(String[] args) {

        ByteArrayOutputStream array = new ByteArrayOutputStream();
        PrintStream stream = new PrintStream(array);
        PrintStream original = System.out;

        System.setOut(stream);

        testString.printSomething();
        System.setOut(original);

        int count = 0;
        for (byte b : array.toByteArray()) {
            if (b == (char)'\n') {
                count ++;
            }
            System.out.print((char)b);
            if (count > 1) {
                count = 0;
                System.out.println("JavaRush - курсы Java онлайн");
            }
        }

   }

    public static class TestString {
        public void printSomething() {
            System.out.println("first");
            System.out.println("second");
            System.out.println("third");
            System.out.println("fourth");
            System.out.println("fifth");
        }
    }
}
