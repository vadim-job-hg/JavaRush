package com.javarush.task.task19.task1907;

/* 
Считаем слово
*/

/* Считаем слово
Считать с консоли имя файла.
Файл содержит слова, разделенные знаками препинания.
Вывести в консоль количество слов "world", которые встречаются в файле.
Закрыть потоки. Не использовать try-with-resources
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Solution {
    public static void main(String[] args){
        try {
            BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));

            FileReader fileReader = new FileReader(sc.readLine());
            BufferedReader in = new BufferedReader(fileReader);
            sc.close();

            StringBuilder sb = new StringBuilder();
            String s;

            while ((s = in.readLine()) != null) {
                sb.append(s + ",");
            }
            in.close();
            fileReader.close();

            String[] words = sb.toString().split(" ");
            int counter = 0;

            for (String str: words) {
                if (str.equals("world")) counter++;
            }
            System.out.println(counter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}