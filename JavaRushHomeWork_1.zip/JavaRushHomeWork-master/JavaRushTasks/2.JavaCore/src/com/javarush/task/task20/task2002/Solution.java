package com.javarush.task.task20.task2002;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/* 
Читаем и пишем в файл: JavaRush
*/
public class Solution {
    public static void main(String[] args) {
        //you can find your_file_name.tmp in your TMP directory or fix outputStream/inputStream according to your real file location
        //вы можете найти your_file_name.tmp в папке TMP или исправьте outputStream/inputStream в соответствии с путем к вашему реальному файлу
        try {
            //File your_file_name = File.createTempFile("your_file_name", null);
            File your_file_name =  new File ("d:\\temp.txt");
            OutputStream outputStream = new FileOutputStream(your_file_name);
            InputStream inputStream = new FileInputStream(your_file_name);

            JavaRush javaRush = new JavaRush();
            //initialize users field for the javaRush object here - инициализируйте поле users для объекта javaRush тут
/*
            javaRush.users.add(0, new User());

            javaRush.users.get(0).setFirstName("Dmitry");
            javaRush.users.get(0).setLastName("LastName");
            javaRush.users.get(0).setMale(true);
            //SimpleDateFormat format = new SimpleDateFormat("dd MM yyyy");
            javaRush.users.get(0).setBirthDate(new Date());
            javaRush.users.get(0).setCountry(User.Country.RUSSIA);

*/
            javaRush.save(outputStream);
            outputStream.flush();

            JavaRush loadedObject = new JavaRush();
            loadedObject.load(inputStream);
            //check here that javaRush object equals to loadedObject object - проверьте тут, что javaRush и loadedObject равны

            System.out.println(javaRush.equals(loadedObject));


            System.out.println("javaRush's users:");
            for (User u : javaRush.users) {
                System.out.println(u.getFirstName());
                System.out.println(u.getLastName());
                System.out.println(u.getBirthDate());
                System.out.println(u.getCountry());
                System.out.println(u.isMale());
            }
            System.out.println("loadedObject's users:");
            for (User u : loadedObject.users) {
                System.out.println(u.getFirstName());
                System.out.println(u.getLastName());
                System.out.println(u.getBirthDate());
                System.out.println(u.getCountry());
                System.out.println(u.isMale());
            }


            System.out.println(javaRush.users.size());
            System.out.println(loadedObject.users.size());

            outputStream.close();
            inputStream.close();

        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Oops, something wrong with my file");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Oops, something wrong with save/load method");
        }
    }

    public static class JavaRush {
        public List<User> users = new ArrayList<>();

        public void save(OutputStream outputStream) throws Exception {
            //implement this method - реализуйте этот метод
            PrintStream file = new PrintStream(outputStream);

            for (User u : users) {
                file.println("u.getFirstName():" + u.getFirstName());
                file.println("u.getLastName():" + u.getLastName());
                file.println("u.getBirthDate():" + u.getBirthDate().getTime());
                file.println("u.isMale():" + u.isMale());
                if (u.getCountry().equals(User.Country.RUSSIA))
                    file.println("u.getCountry():1");
                else if (u.getCountry().equals(User.Country.UKRAINE))
                    file.println("u.getCountry():0");
                else if (u.getCountry().equals(User.Country.OTHER))
                    file.println("u.getCountry():3");
            }
            file.flush();
            file.close();
        }

        public void load(InputStream inputStream) throws Exception {
            //implement this method - реализуйте этот метод
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            while (true){
                String s = "";
                s = reader.readLine();
                if (s != null) {
                    users.add(0, new User());
                    users.get(0).setFirstName(s.replace("u.getFirstName():", ""));
                    users.get(0).setLastName(reader.readLine().replace("u.getLastName():", ""));
                    s = reader.readLine().replace("u.getBirthDate():", "");
                    //System.out.println(s);
                    users.get(0).setBirthDate(new Date(Long.parseLong(s)));
                    users.get(0).setMale(reader.readLine().replace("u.isMale():","").equals("true") ? true : false);
                    s = reader.readLine().replace("u.getCountry():", "");
                    if (s.equals("1")){
                    //    System.out.println("1111");
                        users.get(0).setCountry(User.Country.RUSSIA);}
                    else if (s.equals("0")) {
                            users.get(0).setCountry(User.Country.UKRAINE);}
                    else {
                        users.get(0).setCountry(User.Country.OTHER);}

                } else
                    break;
            }
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            JavaRush javaRush = (JavaRush) o;

            return users != null ? users.equals(javaRush.users) : javaRush.users == null;

        }

        @Override
        public int hashCode() {
            return users != null ? users.hashCode() : 0;
        }
    }
}
