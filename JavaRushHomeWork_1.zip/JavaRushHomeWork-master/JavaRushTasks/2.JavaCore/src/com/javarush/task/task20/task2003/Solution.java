package com.javarush.task.task20.task2003;

import java.io.*;
import java.util.*;

/* 
Знакомство с properties
*/
public class Solution {
    public static Map<String, String> properties = new HashMap<>();
    public static Properties prop = new Properties();

    public  void fillInPropertiesMap() {
        //implement this method - реализуйте этот метод
        BufferedReader console = null;

        try {
            console = new BufferedReader(new InputStreamReader(System.in));
            String fileName = console.readLine();

            load(new FileInputStream(fileName));

        } catch (Exception e) {}
    }

    public  void save(OutputStream outputStream) throws Exception {
        //implement this method - реализуйте этот метод
        prop.putAll(properties);

        PrintWriter writer = new PrintWriter(outputStream);

        prop.store(writer, "comment");
    }

    public  void load(InputStream inputStream) throws Exception {
        //implement this method - реализуйте этот метод
        prop.load(inputStream);
        Set<String> list = prop.stringPropertyNames();
        for (String s : list) {
            properties.put(s, prop.getProperty(s));
        }
    }

    public static void main(String[] args) {
        /*fillInPropertiesMap();
        try {
            save(new FileOutputStream("d:\\1.txt"));
        } catch (Exception e){}*/
    }
}
