package com.javarush.task.task19.task1921;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/* 
Хуан Хуанович
*/

public class Solution {
    public static final List<Person> PEOPLE = new ArrayList<Person>();

    public static void main(String[] args) {
        FileReader fileReader= null;
        try {
            fileReader = new FileReader(args[0]);
            BufferedReader reader = new BufferedReader(fileReader);

            String str = "";
            while ((str = reader.readLine()) != null) {
                String[] array = str.split(" ");
                int year = Integer.parseInt(array[array.length - 1]);
                int month = Integer.parseInt(array[array.length - 2]);
                int day = Integer.parseInt(array[array.length - 3]);
                StringBuilder fio = new StringBuilder();
                for (int i = 0; i < array.length - 3; i ++){
                    fio.append(array[i]);
                    fio.append(" ");
                }
                SimpleDateFormat format = new SimpleDateFormat("dd MM yyyy");
                Date bd = format.parse("" + day + " " + month + " " + year);
                PEOPLE.add(new Person(fio.toString().trim(), bd));
            }
/*
            for (Person p : PEOPLE) {
                System.out.println(p.getName() + " " + p.getBirthday());
            }
*/
            reader.close();
            fileReader.close();
        } catch (Exception e) {
            System.out.println("something was wrong!");
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {}
        }
    }
}
