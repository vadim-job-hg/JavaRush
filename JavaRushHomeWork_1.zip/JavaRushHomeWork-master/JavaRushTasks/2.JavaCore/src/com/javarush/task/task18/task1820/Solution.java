package com.javarush.task.task18.task1820;

/* 
Округление чисел
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String file1 = "d:\\1.txt";
        String file2 = "d:\\2.txt";

        try {
            file1 = reader.readLine();
            file2 = reader.readLine();
        } catch (IOException e) {}
        finally {
            try {
                reader.close();
            } catch (IOException e) {}
        }


        try {
            BufferedReader fileReader = new BufferedReader(new FileReader(file1));
            FileOutputStream stream = new FileOutputStream(file2);

            String str = "";

            while ((str = fileReader.readLine()) != null) {
                String[] buffer = str.split(" ");
                for (String s : buffer){
                    int i = (int)Double.parseDouble(s);
                    stream.write((i + " ").getBytes());
//                    System.out.println(s + ":" + Double.parseDouble(s) + ":" + (int)Double.parseDouble(s));
                }
            }
            fileReader.close();
            stream.close();

        } catch (FileNotFoundException e) {}
        catch (IOException e) {}
    }
}
