package com.javarush.task.task19.task1919;

/* 
Считаем зарплаты
*/

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Solution {
    public static void main(String[] args) {
        BufferedReader reader = null;
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(args[0]);
            reader = new BufferedReader(fileReader);

            String str = "";
            Map<String, Double> map = new TreeMap<String, Double>();

            while ((str = reader.readLine()) != null){
                String fio = "";
                try {
                    fio = str.split(" ")[0];
                    double d = 0d;
                    if (map.containsKey(fio)) {
                        d = map.get(fio);
                    }
                    try {
                        d += Double.parseDouble(str.split(" ")[1]);
                    } catch (NumberFormatException e) {
                        System.out.println("parsing's error!");
                    } catch (IndexOutOfBoundsException e) {
                        System.out.println("Index out of bound:" + str);
                    }
                    map.put(fio, d);
                } catch (ArrayIndexOutOfBoundsException e){
                    System.out.println("Index out of bound:" + str);
                }
            }
            try {
                reader.close();
            } catch (IOException e) {}
            //}
            //if (fileReader != null) {
            try {
                fileReader.close();
            } catch (IOException e) {}

            for (Map.Entry<String, Double> entry : map.entrySet()) {
                System.out.println(entry.getKey() + " " + entry.getValue());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File " + args[0] + " not found");
        } catch (IOException e) {
            System.out.println("IOException");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("args error!" + args.toString());
        } finally {
            //if (reader!= null){

            //}
        }

    }
}
