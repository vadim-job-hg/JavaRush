package com.javarush.task.task19.task1917;

/* 
Свой FileWriter
*/

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileWriter;
import java.io.IOException;

public class FileConsoleWriter {
    private FileWriter fileWriter;

    public FileConsoleWriter(String fileName, FileWriter fileWriter) throws IOException {
        this.fileWriter = fileWriter;
    }

    public FileConsoleWriter(String fileName, boolean append, FileWriter fileWriter) throws IOException {
        this.fileWriter = fileWriter;
    }

    public FileConsoleWriter(File file, FileWriter fileWriter) throws IOException {
        this.fileWriter = fileWriter;
    }

    public FileConsoleWriter(File file, boolean append, FileWriter fileWriter) throws IOException {
        this.fileWriter = fileWriter;
    }

    public FileConsoleWriter(FileDescriptor fd, FileWriter fileWriter) {
        this.fileWriter = fileWriter;
    }

    public void write(char[] cbuf) throws IOException {
        fileWriter.write(cbuf);
        System.out.println(cbuf);
    }

    public void write(String str) throws IOException {
        fileWriter.write(str);
        System.out.println(str);
    }

    public static void main(String[] args) {

    }

}
