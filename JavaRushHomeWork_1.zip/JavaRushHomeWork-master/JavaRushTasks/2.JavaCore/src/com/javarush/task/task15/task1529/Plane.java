package com.javarush.task.task15.task1529;

/**
 * Created by Olaf on 16.02.2017.
 */
public class Plane implements Flyable {
    private int i;
    public void fly() {
    }

    public Plane(int i) {
        this.i = i;
    }
}
