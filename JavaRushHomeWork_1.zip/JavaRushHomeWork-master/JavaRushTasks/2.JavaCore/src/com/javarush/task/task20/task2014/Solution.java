package com.javarush.task.task20.task2014;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/* 
Serializable Solution
Написать код проверки самостоятельно в методе main:
1) создать файл, открыть поток на чтение (input stream) и на запись(output stream);
2) создать экземпляр класса Solution — savedObject;
3) записать в поток на запись savedObject (убедитесь, что они там действительно есть);
4) создать другой экземпляр класса Solution с другим параметром;
5) загрузить из потока на чтение объект — loadedObject;
6) проверить, что savedObject.string равна loadedObject.string;
7) обработать исключения.

*/
public class Solution implements Serializable {
    public static void main(String[] args) {

        //System.out.println(new Solution(4));
        File file = new File("d:\\temp.txt");
        try {

            OutputStream streamOutput = new FileOutputStream(file);
            ObjectOutputStream objOutputStream = new ObjectOutputStream(streamOutput);

            Solution savedObject = new Solution(1);
            objOutputStream.writeObject(savedObject);

            streamOutput.close();
            objOutputStream.close();


            InputStream streamInput = new FileInputStream(file);
            ObjectInputStream objInputStream = new ObjectInputStream(streamInput);


            Solution loadedObject = new Solution(2);
            loadedObject = (Solution) objInputStream.readObject();

            objInputStream.close();


            streamInput.close();



            System.out.println(savedObject +"/" + loadedObject);
        } catch (IOException e) {
            System.out.println("IOException");
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            System.out.println("ClassNotFoundException");
        }


    }

    private transient final String pattern = "dd MMMM yyyy, EEEE";
    private transient Date currentDate;
    private transient int temperature;
    String string;

    public Solution(int temperature) {
        this.currentDate = new Date();
        this.temperature = temperature;

        string = "Today is %s, and current temperature is %s C";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        this.string = String.format(string, format.format(currentDate), temperature);
    }

    @Override
    public String toString() {
        return this.string;
    }
}
