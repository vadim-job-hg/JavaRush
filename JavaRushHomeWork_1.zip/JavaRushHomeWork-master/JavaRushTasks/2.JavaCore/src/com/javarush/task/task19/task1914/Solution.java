package com.javarush.task.task19.task1914;

/* 
Решаем пример
*/

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

public class Solution {
    public static TestString testString = new TestString();

    public static void main(String[] args) {
        PrintStream original = System.out;
        ByteArrayOutputStream streamOutput = new ByteArrayOutputStream();
        PrintStream stream = new PrintStream(streamOutput);

        System.setOut(stream);

        testString.printSomething();

        System.setOut(original);

        String output = streamOutput.toString();
        streamOutput = null;

        try {
            int result = 0;
            int a = Integer.parseInt(output.split(" ")[0]);
            int b = Integer.parseInt(output.split(" ")[2]);

            char o = output.split(" ")[1].charAt(0);
            switch (o) {
                case '-':   result = a - b;
                            break;
                case '+':   result = a + b;
                            break;
                case '*':   result = a * b;
                            break;
            }

            System.out.println(a + " " + o + " " + b + " = " + result);

        } catch (NumberFormatException e) {
            System.out.println("Что-то не так с парсингом аргументов");
        }

    }

    public static class TestString {
        public void printSomething() {
            System.out.println("3 + 6 = ");
        }
    }
}

