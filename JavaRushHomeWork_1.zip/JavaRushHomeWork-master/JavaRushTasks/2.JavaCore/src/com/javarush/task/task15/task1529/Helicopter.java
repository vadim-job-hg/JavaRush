package com.javarush.task.task15.task1529;

/**
 * Created by Olaf on 16.02.2017.
 */
public class Helicopter implements Flyable {
    public void fly() {

    }
}
