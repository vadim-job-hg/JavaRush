package com.javarush.task.task18.task1819;

/* 
Объединение файлов
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileNameSrc = "";
        String fileNameDst = "";
        try {
            fileNameSrc = reader.readLine();
            fileNameDst = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();

        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        FileInputStream streamSrc, streamDst;
        //FileOutputStream streamDst;
        try {
            streamSrc = new FileInputStream(fileNameDst);
            streamDst = new FileInputStream(fileNameSrc);

            byte[] contentSrc = null;
            byte[] contentDst = null;
            if(streamSrc.available() > 0) {
                contentSrc = new byte[streamSrc.available()];
                int i  = streamSrc.read(contentSrc);
            }
            streamSrc.close();
            if (streamDst.available() > 0) {
                contentDst = new byte[streamDst.available()];
                int i = streamDst.read(contentDst);
            }
            streamDst.close();
            streamSrc.close();

            FileOutputStream stream = new FileOutputStream(fileNameSrc);

            stream.write(contentSrc);
            stream.write(contentDst);
            stream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {

        }
    }
}
