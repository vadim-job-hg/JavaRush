package com.javarush.task.task18.task1802;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/* 
Минимальный байт
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();
        reader.close();
        FileInputStream stream = new FileInputStream(fileName);
        int s, min = 0;

        while (stream.available() > 0) {
            s = stream.read();
            min = min > s ? s : min;
            System.out.println(s);
        }
        stream.close();
        System.out.println(min);
    }
}
