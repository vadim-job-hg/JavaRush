package com.javarush.task.task16.task1631.common;

/**
 * Created by Olaf on 19.02.2017.
 */
public class PngReader implements ImageReader {
}
