package com.javarush.task.task18.task1818;

/* 
Два в одном
*/

import java.io.*;

public class Solution {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String file1 = "";
        String file2 = "";
        String file3 = "";

        try {

            file1 = reader.readLine();
            file2 = reader.readLine();
            file3 = reader.readLine();

        } catch (IOException e) {}
        finally {
            try {
                reader.close();
            } catch (IOException e) {}
        }

        byte[] array1;
        byte[] array2;
        byte[] array3;

        try {
            //FileInputStream stream1 = new FileInputStream(file1);
            FileInputStream stream2 = new FileInputStream(file2);
            FileInputStream stream3 = new FileInputStream(file3);

            //array1 = new FileEditor(stream1).getContent();
            array2 = new FileEditor(stream2).getContent();
            array3 = new FileEditor(stream3).getContent();

            System.out.println(new String(array2));

            //stream1.close();
            stream2.close();
            stream3.close();

            FileOutputStream streamOut = new FileOutputStream(file1);

            new FileEditor(streamOut).writeContent((new String(array2) + new String(array3)).getBytes());
            streamOut.close();
        } catch (FileNotFoundException e) {}
        catch (IOException e) {}


    }

    public static class FileEditor {
        private FileInputStream streamInput;
        private FileOutputStream streamOutput;

        public FileEditor(FileInputStream stream) {
            this.streamInput = stream;
        }
        public FileEditor (FileOutputStream stream) {
            this.streamOutput = stream;
        }

        public byte[] getContent() throws IOException{
            byte[] array = new byte[streamInput.available()];
            if (streamInput.available() > 0) {
                int i = streamInput.read(array);
            }
//            System.out.println(new String(array));
            return array;
        }

        public void writeContent(byte[] array) throws IOException{
            streamOutput.write(array);
        }
    }
}
