package com.javarush.task.task01.task0121;

/* 
Контракт
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
    }
}
