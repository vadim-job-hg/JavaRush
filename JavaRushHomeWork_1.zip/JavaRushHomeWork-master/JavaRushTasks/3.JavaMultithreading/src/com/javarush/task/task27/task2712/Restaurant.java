package com.javarush.task.task27.task2712;


import com.javarush.task.task27.task2712.kitchen.Cook;
import com.javarush.task.task27.task2712.kitchen.Dish;
import com.javarush.task.task27.task2712.kitchen.Waiter;

import java.io.IOException;

/**
 * Created by Olaf on 16.03.2017.
 */
public class Restaurant {
    public static void main(String[] args){
        Tablet t = new Tablet(5);
        Cook cook = new Cook("Amigo");
        Waiter waiter = new Waiter();

        t.addObserver(cook);
        cook.addObserver(waiter);

        t.createOrder();
    }
}
