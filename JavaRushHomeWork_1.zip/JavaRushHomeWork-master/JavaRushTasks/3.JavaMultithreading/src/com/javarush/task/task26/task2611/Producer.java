package com.javarush.task.task26.task2611;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Olaf on 12.03.2017.
 */
public class Producer implements Runnable{
    private ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();

    public Producer(ConcurrentHashMap<String, String> map) {
        this.map = map;
    }

    public void run(){
        try {
            int i = 1;
            while(true){
                Thread.sleep(500);
                map.put("" + i, "Some text for " + i++);
            }
        } catch (InterruptedException e) {
            System.out.println(String.format("[%s] thread was terminated", Thread.currentThread().getName()));
        }
    }
}

