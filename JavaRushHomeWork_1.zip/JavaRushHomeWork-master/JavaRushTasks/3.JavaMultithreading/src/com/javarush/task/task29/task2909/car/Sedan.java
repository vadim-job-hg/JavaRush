package com.javarush.task.task29.task2909.car;

/**
 * Created by Olaf on 10.03.2017.
 */
public class Sedan extends Car {
    public Sedan(int numberOfPassengers) {
        super(Car.SEDAN, numberOfPassengers);
    }

    @Override
    public int getMaxSpeed() {
        return Car.MAX_SEDAN_SPEED;
    }
}
