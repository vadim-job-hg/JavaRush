package com.javarush.task.task30.task3008.client;

import com.javarush.task.task30.task3008.ConsoleHelper;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Created by Olaf on 12.03.2017.
 */
public class BotClient extends Client {


    public class BotSocketThread extends Client.SocketThread {
        @Override
        protected void clientMainLoop() throws IOException, ClassNotFoundException {
            BotClient.this.sendTextMessage("Привет чатику. Я бот. Понимаю команды: дата, день, месяц, год, время, час, минуты, секунды.");
            super.clientMainLoop();
        }

        @Override
        protected void processIncomingMessage(String message) {
            ConsoleHelper.writeMessage(message);
            if (message.indexOf(":") > 0) {
                String userName = message.split(": ")[0];
                String command = message.split(": ")[1];

                String format = "";
                if ("дата".equalsIgnoreCase(command))
                    format = "d.MM.YYYY";
                else if ("день".equalsIgnoreCase(command))
                    format = "d";
                else if ("месяц".equalsIgnoreCase(command))
                    format = "MMMM";
                else if ("год".equalsIgnoreCase(command))
                    format = "YYYY";
                else if ("время".equalsIgnoreCase(command))
                    format = "H:mm:ss";
                else if ("час".equalsIgnoreCase(command))
                    format = "H";
                else if ("минуты".equalsIgnoreCase(command))
                    format = "m";
                else if ("секунды".equalsIgnoreCase(command))
                    format = "s";
                else return;
                SimpleDateFormat sdf = new SimpleDateFormat(format);
                sendTextMessage("Информация для " + userName + ": " + sdf.format(new GregorianCalendar().getTime()));
            }
        }
    }

    @Override
    protected SocketThread getSocketThread() {
        return new BotSocketThread();
    }

    @Override
    protected boolean shouldSendTextFromConsole() {
        return false;
    }

    @Override
    protected String getUserName() {
        return String.format("date_bot_%d", ((int) (Math.random() * 100)));
    }

    public static void main(String[] args) {
        new BotClient().run();
    }
}
