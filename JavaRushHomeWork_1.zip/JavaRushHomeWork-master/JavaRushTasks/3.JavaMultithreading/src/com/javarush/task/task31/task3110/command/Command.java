package com.javarush.task.task31.task3110.command;

public interface Command {
    void execute() throws Exception;
}
