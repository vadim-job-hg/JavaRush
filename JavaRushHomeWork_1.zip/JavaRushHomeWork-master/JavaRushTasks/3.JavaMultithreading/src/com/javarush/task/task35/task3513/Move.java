package com.javarush.task.task35.task3513;

/**
 * Created by Olaf on 22.03.2017.
 */

//@FunctionalInterface
public interface Move {
    public void move();
    //

}
