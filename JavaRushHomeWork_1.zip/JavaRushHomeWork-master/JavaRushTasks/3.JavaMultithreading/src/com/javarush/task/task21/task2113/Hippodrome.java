package com.javarush.task.task21.task2113;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Olaf on 01.03.2017.
 */
public class Hippodrome {
    public static Hippodrome game;
    private List<Horse> horses;

    public List<Horse> getHorses() {
        return horses;
    }

    public Hippodrome(List<Horse> horses) {
        this.horses = horses;
    }

    public void run(){
        for (int i = 0; i < 100; i ++){
            move();
            print();
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void print() {
        for (Horse horse : horses) {
            horse.print();
        }
        for (int i = 0; i < 10; i ++){
            System.out.println();
        }
    }
    public void move(){
        for (Horse horse : horses) {
            horse.move();
        }
    }

    public Horse getWinner() {
        double max = 0d;
        for (Horse horse : horses) {
            max = horse.getDistance() > max ? horse.getDistance() : max;
        }
        for (Horse horse : horses) {
            if (horse.getDistance() == max)
                return horse;
        }
        return null;
    }

    public void printWinner() {
        System.out.println("Winner is " + getWinner().getName() + "!");
    }

    public static void main(String[] args) {
        List<Horse> list = new ArrayList<Horse>();
        list.add(new Horse("First", 3, 0));
        list.add(new Horse("Second", 3, 0));
        list.add(new Horse("Third", 3, 0));

        game = new Hippodrome(list);
        game.run();

        game.printWinner();
    }
}
