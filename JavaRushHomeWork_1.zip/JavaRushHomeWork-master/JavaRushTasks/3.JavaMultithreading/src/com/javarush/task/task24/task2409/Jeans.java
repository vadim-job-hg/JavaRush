package com.javarush.task.task24.task2409;

/**
 * Created by Olaf on 06.03.2017.
 */
public interface Jeans extends Item {
    int getLength();
    int getSize();
}
