package com.javarush.task.task25.task2508;

public class TaskManipulator implements CustomThreadManipulator {
    private String threadName;
    private boolean isStoped;

    public void run() {
        //while (!isStoped) {
            try {
                Thread.sleep(100);
                //System.out.println(threadName);
            } catch (InterruptedException e) {
                isStoped = true;
            }
        //}
    }

    //@Override
    public void start(String threadName) {
        this.threadName = threadName;
        while (!isStoped) {
            run();
        }
    }

    //@Override
    public void stop() {
        isStoped = true;
        System.out.println("stop");
    }
}
