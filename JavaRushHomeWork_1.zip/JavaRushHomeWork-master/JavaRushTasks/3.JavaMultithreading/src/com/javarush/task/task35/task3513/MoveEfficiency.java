package com.javarush.task.task35.task3513;

/**
 * Created by Olaf on 22.03.2017.
 */
public class MoveEfficiency implements Comparable{
    private int numberOfEmptyTiles;
    private int score;
    private Move move;

    public MoveEfficiency(int numberOfEmptyTiles, int score, Move move) {
        this.numberOfEmptyTiles = numberOfEmptyTiles;
        this.score = score;
        this.move = move;
    }

    public Move getMove() {
        return move;
    }

    @Override
    public int compareTo(Object o) {
        MoveEfficiency another = (MoveEfficiency) o;
        int result = numberOfEmptyTiles - another.numberOfEmptyTiles;
        if (result == 0)
            return score - another.score;

        return result;
    }
}
