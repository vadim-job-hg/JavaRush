package com.javarush.task.task26.task2601;

import java.util.Arrays;
import java.util.Comparator;
/*
Почитать в инете про медиану выборки
*/
public class Solution {


    public static void main(String[] args) {
  }

    public static Integer[] sort(Integer[] array) {
        //implement logic here
        if (array.length == 0 || array == null)
            return null;

        Arrays.sort(array);
        final double mediana;
        if (array.length % 2 != 0)
            mediana = array[(array.length / 2)];
        else
            mediana = (array[array.length / 2 - 1] + array[array.length / 2]) / 2;

        Comparator comparatorByMedian = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Double.compare(Math.abs(mediana - o1), Math.abs(mediana - o2));

            }
        };
        Arrays.sort(array, comparatorByMedian);
        return array;
    }
}
