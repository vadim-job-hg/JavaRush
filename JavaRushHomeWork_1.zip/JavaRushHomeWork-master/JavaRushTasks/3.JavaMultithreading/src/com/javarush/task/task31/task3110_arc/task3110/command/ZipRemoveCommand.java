package com.javarush.task.task31.task3110_arc.task3110.command;

/**
 * Created by Olaf on 13.03.2017.
 */
public class ZipRemoveCommand extends ZipCommand {
    @Override
    public void execute() throws Exception {

    }
}
