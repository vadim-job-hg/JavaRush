package com.javarush.task.task27.task2712.ad;

/**
 * Created by Olaf on 18.03.2017.
 */
public class NoVideoAvailableException extends RuntimeException {
}
