package com.javarush.task.task31.task3110_arc.task3110.exception;

public class WrongZipFileException extends Exception {
}
