package com.javarush.task.task3709.security;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public interface SecurityChecker {
    boolean performSecurityCheck();
}

