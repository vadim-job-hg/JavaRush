package com.javarush.task.task39.task3913;

import com.javarush.task.task39.task3913.query.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class LogParser implements IPQuery, UserQuery, DateQuery, EventQuery, QLQuery {
    private Path logDir;
    private List<ParsedEntity> content = new ArrayList<>();

    public LogParser(Path logDir) {
        this.logDir = logDir;
        this.content = getContent();
    }

    @Override
    public int getNumberOfUniqueIPs(Date after, Date before) {
        return getUniqueIPs(after, before).size();
    }

    @Override
    public Set<String> getUniqueIPs(Date after, Date before) {
        Set<String> ips = new HashSet<String>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            ips.add(entity.getIp());
        }

        return ips;
    }

    @Override
    public Set<String> getIPsForUser(String user, Date after, Date before) {
        Set<String> ipsForUser = new HashSet<String>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (user.equalsIgnoreCase(entity.getUserName()))
                ipsForUser.add(entity.getIp());
        }

        return ipsForUser;
    }

    @Override
    public Set<String> getIPsForEvent(Event event, Date after, Date before) {
        Set<String> ipsForEvent = new HashSet<String>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (event == entity.getEvent())
                ipsForEvent.add(entity.getIp());
        }

        return ipsForEvent;
    }

    @Override
    public Set<String> getIPsForStatus(Status status, Date after, Date before) {
        Set<String> ipsForStatus = new HashSet<String>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {

            if (status == entity.getStatus())
                ipsForStatus.add(entity.getIp());

        }

        return ipsForStatus;
    }

    @Override
    public Set<String> getAllUsers() {
        Set<String> allUsers = new HashSet<>();

        for (ParsedEntity entity : content)
            allUsers.add(entity.getUserName());

        return allUsers;
    }

    @Override
    public int getNumberOfUsers(Date after, Date before) {
        List<ParsedEntity> content = getContentByPeriod(after, before);
        Set<String> users = new HashSet<>();

        for (ParsedEntity entity : content)
            users.add(entity.getUserName());

        return users.size();
    }

    @Override
    public int getNumberOfUserEvents(String user, Date after, Date before) {
        Set<Event> events = new HashSet<>();

        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (entity.getUserName().equalsIgnoreCase(user))
                events.add(entity.getEvent());
        }

        return events.size();
    }

    @Override
    public Set<String> getUsersForIP(String ip, Date after, Date before) {
        Set<String> usersForIp = new HashSet<>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content)
            if (entity.getIp().equalsIgnoreCase(ip))
                usersForIp.add(entity.getUserName());

        return usersForIp;
    }

    @Override
    public Set<String> getLoggedUsers(Date after, Date before) {
        Set<String> users = getUsersByCriteria(Event.LOGIN, after, before);
        return users;
    }

    @Override
    public Set<String> getDownloadedPluginUsers(Date after, Date before) {
        Set<String> users = getUsersByCriteria(Event.DOWNLOAD_PLUGIN, after, before);
        return users;
    }

    @Override
    public Set<String> getWroteMessageUsers(Date after, Date before) {
        Set<String> users = getUsersByCriteria(Event.WRITE_MESSAGE, after, before);
        return users;
    }

    @Override
    public Set<String> getSolvedTaskUsers(Date after, Date before) {
        Set<String> users = getUsersByCriteria(Event.SOLVE_TASK, after, before);
        return users;
    }

    @Override
    public Set<String> getSolvedTaskUsers(Date after, Date before, int task) {
        Set<String> users = getUsersByCriteriaAndTask(Event.SOLVE_TASK, task, after, before);
        return users;
    }

    @Override
    public Set<String> getDoneTaskUsers(Date after, Date before) {
        Set<String> users = getUsersByCriteria(Event.DONE_TASK, after, before);
        return users;
    }

    @Override
    public Set<String> getDoneTaskUsers(Date after, Date before, int task) {
        Set<String> users = getUsersByCriteriaAndTask(Event.DONE_TASK, task, after, before);
        return users;
    }


    private Set<String> getUsersByCriteria(Object filterCriteria, Date after, Date before) {
        Set<String> usersByCriteria = new HashSet<>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (filterCriteria instanceof Event)
                if (entity.getEvent() == filterCriteria)
                    usersByCriteria.add(entity.getUserName());
        }

        return usersByCriteria;
    }

    private Set<String> getUsersByCriteriaAndTask(Object filterCriteria, Integer numTask, Date after, Date before) {
        Set<String> usersByCriteria = new HashSet<>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (filterCriteria instanceof Event)
                if (entity.getEvent() == filterCriteria && numTask == entity.getNumTask())
                    usersByCriteria.add(entity.getUserName());
        }

        return usersByCriteria;
    }


    //---method of DateQuery

    @Override
    public Set<Date> getDatesForUserAndEvent(String user, Event event, Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                new Event[]{event},
                null,
                user,
                null,
                -1,
                Date.class);
    }

    @Override
    public Set<Date> getDatesWhenSomethingFailed(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                Status.valueOf("FAILED"),
                null,
                null,
                -1,
                Date.class);
    }

    @Override
    public Set<Date> getDatesWhenErrorHappened(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                Status.valueOf("ERROR"),
                null,
                null,
                -1,
                Date.class);
    }

    @Override
    public Date getDateWhenUserLoggedFirstTime(String user, Date after, Date before) {
        Set<Date> datesWhenUserLogged = getEntityByCriteria(
                after,
                before,
                new Event[]{Event.LOGIN},
                null,
                user,
                null,
                -1,
                Date.class);
        Date dateWhenUserLoggedFirstTime = null;

        for (Date date : datesWhenUserLogged) {
            dateWhenUserLoggedFirstTime = dateWhenUserLoggedFirstTime == null || dateWhenUserLoggedFirstTime.compareTo(date) > 0 ?
                    date : dateWhenUserLoggedFirstTime;
        }

        return dateWhenUserLoggedFirstTime;
    }

    @Override
    public Date getDateWhenUserSolvedTask(String user, int task, Date after, Date before) {
        Set<Date> dateWhenUserSolvedTask = getEntityByCriteria(
                after,
                before,
                new Event[]{Event.SOLVE_TASK},
                null,
                user,
                null,
                task,
                Date.class);
        Date dateWhenUserSolvedTaskFirstTime = null;

        for (Date date : dateWhenUserSolvedTask) {
            dateWhenUserSolvedTaskFirstTime = dateWhenUserSolvedTaskFirstTime == null ||
                    dateWhenUserSolvedTaskFirstTime.compareTo(date) > 0 ?
                    date :
                    dateWhenUserSolvedTaskFirstTime;
        }

        return dateWhenUserSolvedTaskFirstTime;
    }

    @Override
    public Date getDateWhenUserDoneTask(String user, int task, Date after, Date before) {
        Set<Date> dateWhenUserDoneTask = getEntityByCriteria(
                after,
                before,
                new Event[]{Event.DONE_TASK},
                null,
                user,
                null,
                task,
                Date.class);
        Date dateWhenUserDoneTaskFirstTime = null;

        for (Date date : dateWhenUserDoneTask) {
            dateWhenUserDoneTaskFirstTime = dateWhenUserDoneTaskFirstTime == null ||
                    dateWhenUserDoneTaskFirstTime.compareTo(date) > 0 ?
                    date :
                    dateWhenUserDoneTaskFirstTime;
        }

        return dateWhenUserDoneTaskFirstTime;
    }

    @Override
    public Set<Date> getDatesWhenUserWroteMessage(String user, Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                new Event[]{Event.WRITE_MESSAGE},
                null,
                user,
                null,
                -1,
                Date.class);
    }

    @Override
    public Set<Date> getDatesWhenUserDownloadedPlugin(String user, Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                new Event[]{Event.DOWNLOAD_PLUGIN},
                null,
                user,
                null,
                -1,
                Date.class);
    }


    public <T> Set<T> getEntityByCriteria(Date after, Date before, Event[] events, Status status, String user, String ip,
                                          int task, Class<? extends Object> classez) {
        Set<T> datesByCriteria = new HashSet<T>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {

            //проверяем совпадение по полю Event
            if (events != null) {
                boolean isCorrect = false;
                for (Event event : events)
                    if (event != null && event == entity.getEvent()) {
                        isCorrect = true;
                        break;
                    }
                if (!isCorrect)
                    continue;
            }
            if (status != null && status != entity.getStatus())
                continue;
            if (user != null && !user.equalsIgnoreCase(entity.getUserName()))
                continue;
            if (ip != null && !ip.equalsIgnoreCase(entity.getIp()))
                continue;
            if (task != -1 && entity.getNumTask() != task)
                continue;

            if (classez == Date.class)
                datesByCriteria.add((T) entity.getDate());
            else if (classez == Event.class)
                datesByCriteria.add((T) entity.getEvent());
        }

        return datesByCriteria;
    }
    //---end of method of DateQuery

    //---methods of EventQuery
    @Override
    public int getNumberOfAllEvents(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                null,
                null,
                null,
                -1,
                Event.class).size();
    }

    @Override
    public Set<Event> getAllEvents(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                null,
                null,
                null,
                -1,
                Event.class
        );
    }

    @Override
    public Set<Event> getEventsForIP(String ip, Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                null,
                null,
                ip,
                -1,
                Event.class
        );
    }

    @Override
    public Set<Event> getEventsForUser(String user, Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                null,
                user,
                null,
                -1,
                Event.class
        );
    }

    @Override
    public Set<Event> getFailedEvents(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                Status.valueOf("FAILED"),
                null,
                null,
                -1,
                Event.class
        );
    }

    @Override
    public Set<Event> getErrorEvents(Date after, Date before) {
        return getEntityByCriteria(
                after,
                before,
                null,
                Status.valueOf("ERROR"),
                null,
                null,
                -1,
                Event.class
        );
    }

    @Override
    public int getNumberOfAttemptToSolveTask(int task, Date after, Date before) {
        int number = getAllSolvedTasksAndTheirNumber(after, before).containsKey(task) ?
                getAllSolvedTasksAndTheirNumber(after, before).get(task) :
                0;
        return number;
    }

    @Override
    public int getNumberOfSuccessfulAttemptToSolveTask(int task, Date after, Date before) {
        int number = getAllDoneTasksAndTheirNumber(after, before).containsKey(task) ?
                getAllDoneTasksAndTheirNumber(after, before).get(task) :
                0;
        return number;
    }

    @Override
    public Map<Integer, Integer> getAllSolvedTasksAndTheirNumber(Date after, Date before) {
        return getMapOfTasks(
                after,
                before,
                new Event[]{Event.SOLVE_TASK},
                null,
                -1
        );
    }

    @Override
    public Map<Integer, Integer> getAllDoneTasksAndTheirNumber(Date after, Date before) {
        return getMapOfTasks(
                after,
                before,
                new Event[]{Event.DONE_TASK},
                null,
                -1
        );
    }

    private Map<Integer, Integer> getMapOfTasks(Date after, Date before, Event[] events, Status status, int task) {
        Map<Integer, Integer> mapOfTasks = new HashMap<>();
        List<ParsedEntity> content = getContentByPeriod(after, before);

        for (ParsedEntity entity : content) {
            if (status != null && status != entity.getStatus())
                continue;
            ;
            if (task != -1 && task != entity.getNumTask())
                continue;

            for (Event event : events) {
                if (event != null && event == entity.getEvent()) {
                    int numTask = entity.getNumTask();
                    int count = mapOfTasks.containsKey(numTask) ?
                            mapOfTasks.get(numTask) :
                            0;
                    mapOfTasks.put(entity.getNumTask(), ++count);
                }
            }
        }

        return mapOfTasks;
    }

    //---end of methods of EventQuery

    //---methods of QLQuery

    @Override
    public Set<Object> execute(String query) {
        Set<Object> queryResult = new HashSet<>();
        String[] queryCommands = new String[]{
                "get ip",
                "get user",
                "get date",
                "get event",
                "get status"};
//        Arrays.sort(queryCommands);
//        if (Arrays.binarySearch(queryCommands, query) < 0) {
//            return null;
//        }

        switch (query.toLowerCase()) {
            case "get ip":
                queryResult.addAll(getUniqueIPs(null, null));
                break;
            case "get user":
                queryResult.addAll(getAllUsers());
                break;
            case "get date":
                queryResult.addAll(getNullSet(Date.class));
                break;
            case "get event":
                queryResult.addAll(getAllEvents(null, null));
                break;
            case "get status":
                queryResult.addAll(getNullSet(Status.class));
                break;
            default:
                queryResult.addAll(getQuerySet(query));
                break;
        }

        return queryResult;
    }

    private <T> Set<T> getNullSet(Class<? extends Object> classezz) {
        Set<T> nullSet = new HashSet<>();

        for (ParsedEntity entity : content) {
            if (classezz == Date.class)
                nullSet.add((T) entity.getDate());
            else if (classezz == Status.class)
                nullSet.add((T) entity.getStatus());
        }
        return nullSet;
    }

    private <T> Set<T> getQuerySet(String query) {
        Set<T> querySet = new HashSet<>();

        String[] line = query.split(" ");
        if (line.length >= 6) {
            String field1 = line[1];
            String field2 = line[3];

            //value can contain space symbol
            String value1 = query.split("\"")[1];
            //exclusive parsing date value
            if ("date".equalsIgnoreCase(field2)){
                try {
                    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                    Date date = format.parse(value1);
                    value1 = format.format(date);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            //parsing date period if it exist
            List<ParsedEntity> contentLocal = new ArrayList<>();
            contentLocal = content;
            if (query.contains("between")) {
                SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                try {
                    Date after = format.parse(query.split("\"")[3]);
                    Date before = format.parse(query.split("\"")[5]);
                    contentLocal = getContentByPeriod(after, before);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }


            Method method1 = null;
            Method method2 = null;
            for (Method method : ParsedEntity.class.getDeclaredMethods()){
                if (method.getName().toUpperCase().contains(field1.toUpperCase())) {
                    method1 = method;
                }
                if (method.getName().toUpperCase().contains(field2.toUpperCase())) {
                    method2 = method;
                }
            }

//            System.out.println(query + ": field1=" + field1 + ",field2=" + field2 + ",value1=" + value1);
//            System.out.println("method1=" + method1.getName() + ", method2=" + method2.getName());

            if (method1 != null && method2 != null) {
                for (ParsedEntity entity : contentLocal) {
                    try {
                        String output = "";
                        if (method2.getName().contains("Date")) {
                            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
                            output = format.format(method2.invoke(entity));
                        } else
                            output = String.valueOf(method2.invoke(entity));


                        if (output.equals(value1)) {
                            querySet.add((T) method1.invoke(entity));
                        }
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        return querySet;
    }

    //---end methods of QLQuery

    //-----
    //Функции парсинга обрабатываемого каталога
    //-----
    //функция парсинга считанной строки.
    public ParsedEntity getParsedLine(String line) throws ParseException, IllegalArgumentException {
        ParsedEntity entity;

        String arrayLine[] = line.split("\\t");

        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        Date date = format.parse(arrayLine[2]);
        Event event = Event.valueOf(arrayLine[3].split(" ")[0]);
        Status status = Status.valueOf(arrayLine[4]);

        entity = new ParsedEntity(arrayLine[0],
                arrayLine[1],
                date,
                event,
                status);

        if (arrayLine[3].contains(" "))
            entity.setNumTask(Integer.parseInt(arrayLine[3].split(" ")[1]));

        return entity;
    }

    //функция проверки даты - попадает ли она в заданный диапазон
    public boolean isCorrectDate(Date date, Date after, Date before) {

        if (((after == null) || (date.compareTo(after) >= 0)) &&
                ((before == null) || (date.compareTo(before) <= 0))) {

            return true;

        }

        return false;
    }

    public List<ParsedEntity> getContentByPeriod(Date after, Date before) {
        List<ParsedEntity> entityByPeriod = new ArrayList<>();

        for (ParsedEntity entity : content) {
            if (isCorrectDate(entity.getDate(), after, before))
                entityByPeriod.add(entity);
        }

        return entityByPeriod;
    }

    public List<ParsedEntity> getContent() {
        final List<ParsedEntity> content = new ArrayList<ParsedEntity>();

        try {
            Files.walkFileTree(logDir, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    if (file.toString().toUpperCase().endsWith(".LOG")) {
                        try (BufferedReader reader = Files.newBufferedReader(file, Charset.defaultCharset())) {

                            String line;
                            while ((line = reader.readLine()) != null) {
                                //parsing line
                                try {
                                    ParsedEntity entity = getParsedLine(line);
                                    content.add(entity);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                } catch (IllegalArgumentException e) {
                                    e.printStackTrace();
                                }
                            }

                        }
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            //e.printStackTrace();
        }

        return content;
    }


    private class ParsedEntity {
        private String ip;
        private String userName;
        private Date date;
        private Event event;
        private Status status;
        private int numTask;

        public ParsedEntity(String ip, String userName, Date date, Event event, Status status) {
            this.ip = ip;
            this.userName = userName;
            this.date = date;
            this.event = event;
            this.status = status;
        }

        public String getIp() {
            return ip;
        }

        public String getUserName() {
            return userName;
        }

        public Date getDate() {
            return date;
        }

        public Event getEvent() {
            return event;
        }

        public Status getStatus() {
            return status;
        }

        public int getNumTask() {
            return numTask;
        }

        public void setNumTask(int numTask) {
            this.numTask = numTask;
        }
    }
}
