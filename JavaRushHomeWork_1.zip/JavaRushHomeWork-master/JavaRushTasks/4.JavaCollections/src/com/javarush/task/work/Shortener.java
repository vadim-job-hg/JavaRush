package com.javarush.task.work;

import com.javarush.task.work.strategy.StorageStrategy;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */
public class Shortener {
    private Long lastId = 0L;
    private StorageStrategy storageStrategy;


    public Shortener(StorageStrategy storageStrategy) {
        this.storageStrategy = storageStrategy;
    }

    public synchronized Long getId(String string) {
        if (storageStrategy.containsValue(string))
            return storageStrategy.getKey(string);
        else {
            storageStrategy.put(++lastId, string);
            return lastId;
        }
    }


    public synchronized String getString(Long id) {
        return storageStrategy.getValue(id);
    }
}
