package com.javarush.task.task37.task3711;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class HardDrive {
    void storeData() {
        System.out.println("Storing data to HDD...");
    }
}

