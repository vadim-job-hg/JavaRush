package com.javarush.task.task38.task3802.task3804;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public enum ExceptionApplicationMessage {
    UNHANDLED_EXCEPTION,
    SOCKET_IS_CLOSED
}
