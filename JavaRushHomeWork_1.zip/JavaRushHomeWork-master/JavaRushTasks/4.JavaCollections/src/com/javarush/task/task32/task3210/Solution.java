package com.javarush.task.task32.task3210;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/* 
Используем RandomAccessFile
*/

public class Solution {
    public static void main(String... args) {
        try {
            RandomAccessFile file = new RandomAccessFile(args[0], "rw");

            byte[] b = new byte[args[2].length()];
            file.seek(Integer.parseInt(args[1]));

            file.read(b, 0, args[2].length());
            file.seek(file.length());

            if (convertByteToString(b).equals(args[2])) {
                file.write("true".getBytes());
            } else
                file.write("false".getBytes());

        } catch (FileNotFoundException e) {e.printStackTrace();}
        catch (IOException e) {e.printStackTrace();}
    }

    public static String convertByteToString(byte[] b) {
        return new String(b);
    }
}
