package com.javarush.task.task3709.security;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class SecurityCheckerImpl implements SecurityChecker {
    @Override
    public boolean performSecurityCheck() {
        System.out.println("SECURITY OK!");
        return true;
    }
}

