package com.javarush.task.task32.task3202;

import java.io.*;

/* 
Читаем из потока
*/
public class Solution {
    public static void main(String[] args) throws IOException {
        //StringWriter writer = getAllDataFromInputStream(new FileInputStream("testFile.log"));
        StringWriter writer = getAllDataFromInputStream(new FileInputStream("d:\\result.txt"));
        //System.out.println("123");
        System.out.println(writer.toString());
    }

    public static StringWriter getAllDataFromInputStream(InputStream is) throws IOException {
        try {
            StringWriter writer = new StringWriter();
            writer.write("");
            writer.flush();
            byte[] b = new byte[0];
            try {
                b = new byte[is.available()];
                is.read(b);
               // int c = 1 / 0;
            } finally {
                if (b.length > 0) {
                    writer.write(new String(b));
                } else
                    writer.write("");
            }
            writer.flush();
            if (writer != null)
                return writer;
            else
                return new StringWriter();
        } catch (Exception e) {return new StringWriter();}

    }
}