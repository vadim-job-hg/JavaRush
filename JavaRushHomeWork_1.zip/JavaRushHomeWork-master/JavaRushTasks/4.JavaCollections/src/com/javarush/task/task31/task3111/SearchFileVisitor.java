package com.javarush.task.task31.task3111;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class SearchFileVisitor extends SimpleFileVisitor<Path> {
    private String partOfName = "";
    private String partOfContent = "";
    private int minSize;
    private int maxSize;
    private List<Path> foundFiles = new ArrayList<Path>();

    public void setPartOfName(String partOfName) {
        this.partOfName = partOfName;
    }

    public void setPartOfContent(String partOfContent) {
        this.partOfContent = partOfContent;
    }

    public void setMinSize(int minSize) {
        this.minSize = minSize;
    }

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public String getPartOfName() {
        return partOfName;
    }

    public String getPartOfContent() {
        return partOfContent;
    }

    public int getMinSize() {
        return minSize;
    }

    public int getMaxSize() {
        return maxSize;
    }

    public List<Path> getFoundFiles() {
        return foundFiles;
    }

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
        boolean checker = true;
        //System.out.println(file.toAbsolutePath());
        //return super.visitFile(file, attrs);
        /*check fila name*/
        if ((partOfName.length() > 0) && (!String.valueOf(file.getFileName()).contains(partOfName))) {
            //System.out.println("partOfName");
            //foundFiles.add(file);
            checker = false;
        }// else


        if (partOfContent.length() > 0) {
            //byte[] b = new byte[(int)Files.size(file)];
            //b = Files.readAllBytes(file);
            byte[] b = Files.readAllBytes(file);
            //System.out.println(new String(b));

            if (new String(b).indexOf(partOfContent) < 0) {
                checker = false;
          //      System.out.println("partOfContent");
            }
        }
        if ((minSize > 0 ) && (Files.size(file) < minSize)) {
            checker = false;
//            System.out.println("minSize");
        }
        if ((maxSize > 0) && (Files.size(file) > maxSize)) {
            checker = false;
//            System.out.println("maxSize");
        }

        if (checker){
            foundFiles.add(file);
        }

        return FileVisitResult.CONTINUE;
    }
}
