package com.javarush.task.task38.task3802.task3801;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class NameIsEmptyException extends Exception {
}
