package com.javarush.task.task33.task3308;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Olaf on 19.03.2017.
 */
@XmlType(name = "shop")
@XmlRootElement
public class Shop {
//    @XmlElementWrapper(name = "goods")
    public Goods goods;

    public int count;
    public double profit;

    public String[] secretData;

    public Shop() {
    }


    //@XmlRootElement
    static class Goods{
        @XmlElement(name="names")
        List<String> names;
    }


    @Override
    public String toString() {
        return "Shop{" +
                "goods=" + goods +
                ", count=" + count +
                ", profit=" + profit +
                ", secretData=" + secretData +
                '}';
    }
}
