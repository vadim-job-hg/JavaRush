package com.javarush.task.task37.task3702.male;

import com.javarush.task.task37.task3702.Human;

/**
 * Created by Olaf on 22.03.2017.
 */
public class Man implements Human {

    @Override
    public String toString() {
        return "Man{}";
    }
}
