package com.javarush.task.task33.task3303;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/* 
Десериализация JSON объекта
*/
public class Solution {
    public static <T> T convertFromJsonToNormal(String fileName, Class<T> clazz) throws IOException {
        T result;
        ObjectMapper mapper = new ObjectMapper();
        InputStream is = new FileInputStream(fileName);
        result = mapper.readValue(is, clazz);
        return result;
    }

    public static void main(String[] args) {

    }
}
