package com.javarush.task.task38.task3802.task3804;

import java.util.Enumeration;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class Factory {
    public static Exception getException(Object enumType) throws Exception{


        if (enumType instanceof ExceptionApplicationMessage) {
            ExceptionApplicationMessage message = (ExceptionApplicationMessage) enumType;
            String string = message.toString().substring(0,1) +
                    message.toString().toLowerCase().replace("_", " ").substring(1);
            throw new Exception(string);
        }
        else if (enumType instanceof ExceptionDBMessage) {
            ExceptionDBMessage message = (ExceptionDBMessage) enumType;
            String string = message.toString().substring(0, 1) +
                    message.toString().toLowerCase().replace("_", " ").substring(1);
            throw new RuntimeException(string);
        }
        else if (enumType instanceof ExceptionUserMessage) {
            ExceptionUserMessage message = (ExceptionUserMessage) enumType;
            String string = message.toString().substring(0, 1) +
                    message.toString().toLowerCase().replace("_", " ").substring(1);
            throw new Error(string);
        }
        else
            throw new IllegalArgumentException();
    }
}
