package com.javarush.task.task37.task3708.retrievers;

import com.javarush.task.task37.task3708.cache.LRUCache;
import com.javarush.task.task37.task3708.storage.Storage;

/**
 * Created by Olaf on 27.03.2017.
 */
public class CachingProxyRetriever implements Retriever {
    private OriginalRetriever originalRetriver;
    private LRUCache lruCache;

    public CachingProxyRetriever(Storage storage) {
        this.originalRetriver = new OriginalRetriever(storage);
        this.lruCache = new LRUCache(20);
    }



    @Override
    public Object retrieve(long id) {
        Object o = lruCache.find(id);

        if (o == null) {
            o = originalRetriver.retrieve(id);
            lruCache.set(id, o);
        }

        return o;
    }
}
