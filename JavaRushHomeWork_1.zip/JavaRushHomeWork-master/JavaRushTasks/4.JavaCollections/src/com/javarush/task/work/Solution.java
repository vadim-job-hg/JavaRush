package com.javarush.task.work;

import com.javarush.task.work.strategy.HashMapStorageStrategy;
import com.javarush.task.work.strategy.StorageStrategy;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */
public class Solution {

    public static Set<Long> getIds(Shortener shortener, Set<String> strings){
        Set<Long> set = new HashSet<>();
        Iterator<String> iterator = strings.iterator();
        while (iterator.hasNext()) {
            set.add(shortener.getId(iterator.next()));
        }

        return set;
    }

    public static Set<String> getStrings(Shortener shortener, Set<Long> keys){
        Set<String> set = new HashSet<String>();

        for (Long key : keys) {
            set.add(shortener.getString(key));
        }

        return set;
    }

    public static void testStrategy(StorageStrategy strategy, long elementsNumber) {
        Helper.printMessage(strategy.getClass().getSimpleName());
        Shortener shortener = new Shortener(strategy);
        HashSet<String> strings = new HashSet<String>();

        for (long i = 0L; i < elementsNumber; i++) {
            strings.add(Helper.generateRandomString());
        }

        Set<Long> ids = new HashSet<>();
        Date startTime = new Date();
        for (String string : strings) {
            ids.add(shortener.getId(string));
        }
        Date endTime = new Date();
        long timeDistance = endTime.getTime() - startTime.getTime();

        Helper.printMessage(String.valueOf(timeDistance));

        Set<String> resultString = new HashSet<>();
        startTime = new Date();
        for (Long id : ids) {
            resultString.add(shortener.getString(id));
        }
        endTime = new Date();
        timeDistance = endTime.getTime() - startTime.getTime();

        Helper.printMessage(String.valueOf(timeDistance));

        String stringChecker = "Тест пройден.";
        /*for (Long id : ids) {
            String buffer = shortener.getString(id);
            if (!strings.contains(buffer) || !resultString.contains(buffer)) {
                stringChecker = "Тест не пройден";
            }
        }*/
        if (strings.size() != resultString.size())
            stringChecker = "Тест не пройден.";

        System.out.println(stringChecker);
    }

    public static void main(String[] args) {
        testStrategy(new HashMapStorageStrategy(), 10_000L);
    }
}
