package com.javarush.task.task31.task3112;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
/*
Загрузчик файлов
*/
public class Solution {

    public static void main(String[] args) throws IOException {
        //Path passwords = downloadFile("https://www.amigo.com/ship/secretPassword.txt", Paths.get("D:/MyDownloads"));
        Path passwords = downloadFile("http://weburg.net/123", Paths.get("D:/test"));

        for (String line : Files.readAllLines(passwords, Charset.defaultCharset())) {
            System.out.println(line);
        }
    }

    public static Path downloadFile(String urlString, Path downloadDirectory) throws IOException {
        // implement this method
        URL url = new URL(urlString);
        Path tmpFile = Files.createTempFile("temp-", ".tmp");

        long l = Files.copy(url.openStream(), tmpFile/*, StandardCopyOption.REPLACE_EXISTING*/);

        if (l > 0) {
            Path result = Files.move(tmpFile, Paths.get(downloadDirectory.toAbsolutePath() + "//" +
                                        urlString.substring(urlString.lastIndexOf("/") + 1))/*, StandardCopyOption.REPLACE_EXISTING*/);
            return result;
        } else {
            System.out.println("download error!");
        }

        return null;
    }
}
