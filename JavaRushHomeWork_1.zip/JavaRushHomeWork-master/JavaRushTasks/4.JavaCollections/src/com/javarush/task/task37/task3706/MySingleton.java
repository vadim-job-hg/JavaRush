package com.javarush.task.task37.task3706;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class MySingleton {
    private static volatile MySingleton instance;
}
