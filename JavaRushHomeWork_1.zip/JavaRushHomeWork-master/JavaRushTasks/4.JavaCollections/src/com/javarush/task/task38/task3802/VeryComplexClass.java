package com.javarush.task.task38.task3802;

import java.io.BufferedReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class VeryComplexClass {
    public void veryComplexMethod() throws Exception {
        //напишите тут ваш код
        BufferedReader reader = Files.newBufferedReader(Paths.get("d:\\test"), Charset.defaultCharset());
    }

    public static void main(String[] args) {

    }
}
