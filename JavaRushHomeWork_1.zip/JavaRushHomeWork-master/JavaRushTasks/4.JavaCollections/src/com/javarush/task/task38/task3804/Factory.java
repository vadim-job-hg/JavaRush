package com.javarush.task.task38.task3804;

/**
 * Created by Olaf on 28.03.2017.
 */
public class Factory {
    public static Throwable  getException(Object obj) throws Exception {
        if (obj != null) {
            if (obj instanceof ExceptionApplicationMessage) {
                ExceptionApplicationMessage message = (ExceptionApplicationMessage) obj;

                String text = message.toString().substring(0, 1) +
                        message.toString().toLowerCase().replace("_", " ").substring(1);

                return new Exception(text);
            } else if (obj instanceof ExceptionDBMessage) {
                ExceptionDBMessage message = (ExceptionDBMessage) obj;

                String text = message.toString().substring(0, 1) +
                        message.toString().toLowerCase().replace("_", " ").substring(1);

                return new RuntimeException(text);
            } else if (obj instanceof ExceptionUserMessage) {
                ExceptionUserMessage message = (ExceptionUserMessage) obj;

                String text = message.toString().substring(0, 1) +
                        message.toString().toLowerCase().replace("_", " ").substring(1);

                return new Error(text);
            }
        }
        return new IllegalArgumentException();
    }
}
