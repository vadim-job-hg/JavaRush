package com.javarush.task.work;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */
public class ExceptionHandler {

    public static void log(Exception e){
        Helper.printMessage(e.toString());
    }
}
