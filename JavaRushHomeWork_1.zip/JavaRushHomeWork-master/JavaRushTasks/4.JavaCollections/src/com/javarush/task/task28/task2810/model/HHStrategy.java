package com.javarush.task.task28.task2810.model;

import com.javarush.task.task28.task2810.vo.Vacancy;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.List;

/**
 * Created by Olaf on 28.03.2017.
 */
public class HHStrategy implements Strategy {
    private static final String URL_FORMAT = "https://ekaterinburg.hh.ru/search/vacancy?text=java+%s&page=%d";

    @Override
    public List<Vacancy> getVacancies(String searchString) {
        Document doc = null;
        try {
            String url = String.format(URL_FORMAT, "Екатеринбург", 1);
            //String url = "https://ekaterinburg.hh.ru/";
            String userAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";
            int timeout = 60 * 1000;

            //doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6").method(Connection.Method.GET).referrer("none").get();
            doc = Jsoup.connect(URL_FORMAT).get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
