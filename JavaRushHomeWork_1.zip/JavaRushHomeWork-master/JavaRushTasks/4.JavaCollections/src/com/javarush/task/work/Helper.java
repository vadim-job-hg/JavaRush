package com.javarush.task.work;

import java.math.BigInteger;
import java.security.SecureRandom;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */
public class Helper {

    public static String generateRandomString(){
        return new BigInteger(100, new SecureRandom()).toString(32);
    }
    public static void printMessage(String message){
        System.out.println(message);
    }
}
