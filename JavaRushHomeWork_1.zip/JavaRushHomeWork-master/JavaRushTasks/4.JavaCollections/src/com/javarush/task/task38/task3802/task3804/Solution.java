package com.javarush.task.task38.task3802.task3804;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class Solution {
    public static Class getFactoryClass() {
        return Factory.class;
    }

    public static void main(String[] args) {
        try {
            Factory.getException(null);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
