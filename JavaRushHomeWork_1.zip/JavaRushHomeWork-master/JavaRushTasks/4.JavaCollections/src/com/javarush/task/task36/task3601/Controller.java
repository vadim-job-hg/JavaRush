package com.javarush.task.task36.task3601;

import java.util.List;

/**
 * Created by Olaf on 22.03.2017.
 */
public class Controller {
    private View view;
    private Model model = new Model();


    public List<String> onDataListShow() {
        return model.getStringDataList();
    }
}
