package com.javarush.task.task37.task3711;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class Solution {
    public static void main(String[] args) {
        new Computer().run();
    }
}
