package com.javarush.task.task33.task3305;

public abstract class Auto {
    protected String name;
    protected String owner;
    protected int age;
}