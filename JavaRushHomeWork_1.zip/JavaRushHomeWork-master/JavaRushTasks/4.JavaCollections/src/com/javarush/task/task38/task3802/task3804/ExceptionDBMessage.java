package com.javarush.task.task38.task3802.task3804;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public enum ExceptionDBMessage {
    NOT_ENOUGH_CONNECTIONS,
    RESULT_HAS_NOT_GOTTEN_BECAUSE_OF_TIMEOUT
}
