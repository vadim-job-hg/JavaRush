package com.javarush.task.task37.task3707;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class HashMapReflectionHelper {
    public static <T> T callHiddenMethod(HashMap map, String methodName) {
        try {
            Method method = map.getClass().getDeclaredMethod(methodName);
            method.setAccessible(true);
            return (T) method.invoke(map);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ignored) {
        }
        return null;
    }
}

//public class HashMapReflectionHelper {
//    private int capacity;
//    private long loadFactor;
//
//    public static int getCapacity(HashMap map) {
//        try {
//            Field tableField = HashMap.class.getDeclaredField("table");
//            tableField.setAccessible(true);
//            Object[] table = (Object[]) tableField.get(map);
//
//            return table == null ? 0 : table.length;
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//
//        return 0;
//    }
//
//    public static float getLoadFactor(HashMap map) {
//        try {
//            Field loadFactor = HashMap.class.getDeclaredField("loadFactor");
//            loadFactor.setAccessible(true);
//
//            return (Float)loadFactor.get(map);
//        } catch (NoSuchFieldException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//        return 0f;
//    }
//}
