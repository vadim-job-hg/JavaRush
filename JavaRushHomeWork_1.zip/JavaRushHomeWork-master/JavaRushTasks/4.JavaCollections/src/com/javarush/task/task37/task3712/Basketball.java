package com.javarush.task.task37.task3712;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class Basketball extends Game{
    public void prepareForTheGame() {
        System.out.println("Preparing for the Basketball game...");
    }

    public void playGame() {
        System.out.println("Playing basketball!");
    }

    public void congratulateWinner() {
        System.out.println("Give it up to the NBA finals champions!!!");
    }
}
