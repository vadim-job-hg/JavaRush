package com.javarush.task.task37.task3710.decorators;

import com.javarush.task.task37.task3710.shapes.Shape;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class RedShapeDecorator extends ShapeDecorator {

    public RedShapeDecorator(Shape decoratedShape) {
        super(decoratedShape);
    }

    @Override
    public void draw() {
        setBorderColor(this.decoratedShape);
        super.draw();
    }

    private void setBorderColor(Shape shapeDecorator) {
        String className = shapeDecorator.getClass().getSimpleName();
        System.out.println(String.format("Setting border color for %s to red.", className));
    }
}
