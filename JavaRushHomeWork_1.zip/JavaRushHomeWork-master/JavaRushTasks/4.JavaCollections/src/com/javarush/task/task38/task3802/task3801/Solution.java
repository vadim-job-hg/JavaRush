package com.javarush.task.task38.task3802.task3801;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class Solution {
    public static void main(String[] args) {
        if (args.length > 0) {
            try {
                System.out.println("Имя содержит " + NameChecker.getNumberOfCharacters(args[0]) + " символов");
            } catch (NameIsNullException e) {
                System.out.println("Ошибка: Имя не задано");
            } catch (NameIsEmptyException e) {
                System.out.println("Ошибка: Имя пустое");
            }  catch (Exception e) {
                System.out.println(e.toString());
            }
        }
    }
}
