package com.javarush.task.task39.task3913;

public enum Event {
    LOGIN,
    DOWNLOAD_PLUGIN,
    WRITE_MESSAGE,
    SOLVE_TASK,
    DONE_TASK
}