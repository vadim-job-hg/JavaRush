package com.javarush.task.task38.task3802.task3804;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public enum ExceptionUserMessage {
    USER_DOES_NOT_EXIST,
    USER_DOES_NOT_HAVE_PERMISSIONS
}