package com.javarush.task.task31.task3113;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

/* 
Что внутри папки?
*/
public class Solution {
    public static class MyFileVisitor extends SimpleFileVisitor<Path>{
        private int countFiles;
        private int countDirs;
        private long size;

        public int getCountFiles() {
            return countFiles;
        }

        public int getCountDirs() {
            return countDirs;
        }

        public long getSize() {
            return size;
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
            countFiles ++;
            size += Files.size(file);
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
            countDirs ++;
            return FileVisitResult.CONTINUE;
        }


    }

    public static void main(String[] args) throws IOException {
        BufferedReader console = null;
        try {
            console = new BufferedReader(new InputStreamReader(System.in));
            String dirName = console.readLine();

            Path dir = Paths.get(dirName);
            /*Проверка является ли папкой*/
            if (!Files.isDirectory(dir)) {
                System.out.println(dir.toAbsolutePath() + " - не папка");
                return;
                //System.exit(0);
            }

            MyFileVisitor mfv = new MyFileVisitor();

            Files.walkFileTree(dir, mfv);

            System.out.println("Всего папок - " + (mfv.getCountDirs() - 1));
            System.out.println("Всего файлов - " + mfv.getCountFiles());
            System.out.println("Общий размер - " + mfv.getSize());
        } catch (IOException e) {}
        finally {
            if (console != null) {
                try {
                    console.close();
                } catch (IOException e) {}
            }
        }
    }
}
