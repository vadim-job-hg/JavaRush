package com.javarush.task.task38.task3802.task3803;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
public class VeryComplexClass {
    public void methodThrowsClassCastException() {
        Set set = new HashSet();
        set.add("123");

        Iterator iterator = set.iterator();
        int i = (Integer) iterator.next();
    }

    public void methodThrowsNullPointerException() {
        String s = null;
        System.out.println(s.length());
    }

    public static void main(String[] args) {
        new VeryComplexClass().methodThrowsClassCastException();
    }
}
