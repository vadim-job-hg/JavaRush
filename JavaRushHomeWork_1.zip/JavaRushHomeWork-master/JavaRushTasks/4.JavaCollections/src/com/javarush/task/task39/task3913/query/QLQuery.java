package com.javarush.task.task39.task3913.query;

/**
 * Created by d.v.hozyashev on 28.03.2017.
 */
import java.util.Set;

public interface QLQuery {
    Set<Object> execute(String query);
}