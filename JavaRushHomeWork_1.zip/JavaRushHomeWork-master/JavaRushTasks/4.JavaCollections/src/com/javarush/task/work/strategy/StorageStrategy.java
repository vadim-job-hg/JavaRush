package com.javarush.task.work.strategy;

/**
 * Created by d.v.hozyashev on 24.03.2017.
 */
public interface StorageStrategy {
    boolean containsKey(Long key);
    boolean containsValue(String value);
    void put(Long key, String value);
    Long getKey(String value);
    String getValue(Long key);
}
