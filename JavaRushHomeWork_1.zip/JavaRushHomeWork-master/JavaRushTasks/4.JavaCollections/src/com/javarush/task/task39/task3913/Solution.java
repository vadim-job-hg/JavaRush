package com.javarush.task.task39.task3913;

import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Solution {
    public static void main(String[] args) {
        LogParser logParser = new LogParser(Paths.get("d:\\test\\logs"));
        System.out.println(logParser.getNumberOfUniqueIPs(null, new Date()));

        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

        try {
//            Set<Date> set = new HashSet<>();
//            set = logParser.getDatesForUserAndEvent("Amigo", Event.valueOf("LOGIN"), null, new Date());
//
//            for (Date date : set) {
//                System.out.println(format.format(date));
//            }
//
//            System.out.println(logParser.getDateWhenUserLoggedFirstTime("Amigo", null, new Date()));
//
//            set = logParser.getDatesWhenErrorHappened(null, new Date());
//
//            for (Date date : set) {
//                System.out.println(format.format(date));
//            }
//
//            System.out.println("event's methods");
//            System.out.println(logParser.getNumberOfAllEvents(null, new Date()));
//
//            Set<Event> setEvent = logParser.getAllEvents(null, new Date());
//
////            for (Event event : setEvent) {
////                System.out.println(event);
////            }
//
//            System.out.println(logParser.getNumberOfAttemptToSolveTask(15, null, null));
//
//            Map<Integer, Integer> map = new HashMap<>();
//            map = logParser.getAllSolvedTasksAndTheirNumber(null, null);
//            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
//                System.out.println(entry.getKey() + ":" + entry.getValue());
//            }

            System.out.println("//-----query statements");
            Set<Object> setObject = new HashSet<>();
            setObject = logParser.execute("get date for event = \"LOGIN\" and date between \"11.12.2013 0:00:00\" and \"03.01.2014 23:59:59\"");

            for (Object obj : setObject) {
                System.out.println(String.valueOf(obj));
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}