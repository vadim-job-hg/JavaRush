package com.javarush.task.task31.task3101;

import java.io.*;
import java.util.Map;
import java.util.TreeMap;

/*
Проход по дереву файлов

1. На вход метода main подаются два параметра.
Первый — path — путь к директории, второй — resultFileAbsolutePath — имя файла, который будет содержать результат.
2. Для каждого файла в директории path и в ее всех вложенных поддиректориях выполнить следующее:
2.1. Если у файла длина в байтах больше 50, то удалить его (используй метод FileUtils.deleteFile).
2.2. Если у файла длина в байтах НЕ больше 50, то для всех таких файлов:
2.2.1. Отсортировать их по имени файла в возрастающем порядке, путь не учитывать при сортировке.
2.2.2. Переименовать resultFileAbsolutePath в ‘allFilesContent.txt‘ (используй метод FileUtils.renameFile).
2.2.3. В allFilesContent.txt последовательно записать содержимое всех файлов из п. 2.2.1. Тела файлов разделять «n«.
Все файлы имеют расширение txt.

*/
public class Solution {
    public static Map<String, String> map = new TreeMap<String, String>();

    public static void main(String[] args) {
        File mainDirectory = new File(args[0]);
        File fileResult =  new File("allFilesContent.txt");
        if (fileResult.exists()) {
            fileResult.delete();
        }

        File srcFile = new File(args[1]);
        if (!srcFile.exists())
            try {
                srcFile.createNewFile();
            } catch (IOException e) {}

        FileUtils.renameFile(srcFile, fileResult);

        scanFolders(mainDirectory);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(fileResult);
        } catch (FileNotFoundException e) {
            System.out.println(fileResult.getAbsolutePath() + " not found");
        }

        /*Вывод результата в файл*/
        for (Map.Entry<String, String> entry : map.entrySet()){
            try {
                FileInputStream fis = new FileInputStream(new File(entry.getValue()));
                byte[] b = new byte[fis.available()];
                fis.read(b);

                fos.write(b);
                b = null;
                fis.close();
                //fos.write(entry.getKey().getBytes());
                fos.write('\n');
            } catch (IOException e) {
                System.out.println("Ошибка при записи имен файлов в выходной файл");
            }
        }
        if (fos != null) {
            try {
                fos.close();
            } catch (IOException e) {
                System.out.println("ОШибка при закрытии потока выходного файла");
            }
        }
    }

    public static void scanFolders(File directory) {
        for (File file : directory.listFiles()) {
            if ((file.isDirectory()) && (!file.isHidden())) {
                scanFolders(file);
            } else {
                /*проверяем размер файлов*/
                if (file.length() > 50) {
                    //удаление файла
                    System.out.println(file.getAbsolutePath() + " имеет размер " + file.length() + " и подлежит удалению");
                } else
                    map.put(file.getName(), file.getAbsolutePath());
            }
        }
    }

    public static void deleteFile(File file) {
        if (!file.delete()) System.out.println("Can not delete file with name " + file.getName());
    }
}
