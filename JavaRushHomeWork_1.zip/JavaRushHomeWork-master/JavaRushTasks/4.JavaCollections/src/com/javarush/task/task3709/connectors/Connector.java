package com.javarush.task.task3709.connectors;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public interface Connector {
    void connect();
}
