package com.javarush.task.task37.task3710.shapes;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class Circle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a shape: CIRCLE!");
    }
}
