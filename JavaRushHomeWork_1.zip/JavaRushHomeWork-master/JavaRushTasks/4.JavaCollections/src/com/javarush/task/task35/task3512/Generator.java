package com.javarush.task.task35.task3512;

public class Generator<T> {
    Class<T> classezz;

    T newInstance() throws InstantiationException, IllegalAccessException{
        return classezz.newInstance();
    }

    public Generator(Class<T> classezz) {
        this.classezz = classezz;
    }
}
