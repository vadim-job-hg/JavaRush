package com.javarush.task.task36.task3606;

import com.javarush.task.task36.task3606.data.second.HiddenClassImplFirst;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

/* 
Осваиваем ClassLoader и Reflection
*/
public class Solution {
    private List<Class> hiddenClasses = new ArrayList<>();
    private String packageName;

    public Solution(String packageName) {
        this.packageName = packageName.substring(1);
    }

    public static void main(String[] args) throws ClassNotFoundException {
        Solution solution = new Solution(Solution.class.getProtectionDomain().getCodeSource().getLocation().getPath() + "com/javarush/task/task36/task3606/data/second");
        solution.scanFileSystem();
        System.out.println(solution.getHiddenClassObjectByKey("hiddenclassimplse"));
        System.out.println(solution.getHiddenClassObjectByKey("hiddenclassimplf"));
        System.out.println(solution.getHiddenClassObjectByKey("packa"));
    }


    public void scanFileSystem() throws ClassNotFoundException {
        try {
            Files.walkFileTree(Paths.get(packageName), new SimpleFileVisitor<Path>(){
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    if (file.toString().endsWith(".class")) {
                        Path newPath = Paths.get(Solution.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(1)).relativize(file);
                        String className = newPath.toString().replace("\\", ".").replace(".class", "");
                        className = className.replace("/", ".");
                        try {
                            Class foundedClass = Class.forName(className);
                            hiddenClasses.add(foundedClass);
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HiddenClass getHiddenClassObjectByKey(String key) {
        HiddenClass result = null;
        for (Class className : hiddenClasses){
            if (className.toString().toUpperCase().indexOf(key.toUpperCase()) >= 0){

                try {
                    Constructor constructor = className.getDeclaredConstructor();
                    constructor.setAccessible(true);
                    result = (HiddenClass) constructor.newInstance();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } finally {
                    break;
                }

            }
        }
        return result;
    }
}

