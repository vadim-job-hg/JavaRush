package com.javarush.task.task36.task3601;

/**
 * Created by Olaf on 22.03.2017.
 */
public class View {
    private Controller controller;

    public View(Controller controller) {
        this.controller = controller;
    }

    public View() {
        controller = new Controller();
    }

    public void fireEventShowData() {
        System.out.println(controller.onDataListShow());
    }
}
