package com.javarush.task.task39.task3913;

public enum Status {
    OK,
    FAILED,
    ERROR
}