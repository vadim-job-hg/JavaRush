package com.javarush.task.task32.task3203;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

/*
Пишем стек-трейс
*/
public class Solution {
    public static void main(String[] args) {
        String text = getStackTrace(new IndexOutOfBoundsException("fff"));
        System.out.println(text);
    }

    public static String getStackTrace(Throwable throwable) {

        StringWriter strWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(strWriter);

        throwable.printStackTrace(writer);
        String result = strWriter.toString().replace("\r\n", "");
        //System.out.println(result.replace("\r\n", "1"));
        return result;
    }
}