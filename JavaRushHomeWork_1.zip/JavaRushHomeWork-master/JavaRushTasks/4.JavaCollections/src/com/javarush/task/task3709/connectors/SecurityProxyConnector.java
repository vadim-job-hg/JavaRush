package com.javarush.task.task3709.connectors;

import com.javarush.task.task3709.security.SecurityChecker;
import com.javarush.task.task3709.security.SecurityCheckerImpl;

/**
 * Created by d.v.hozyashev on 27.03.2017.
 */
public class SecurityProxyConnector implements Connector {
    private String resourceString;
    private SimpleConnector simpleConnector;
    private SecurityChecker securityCheckerImpl;

    public SecurityProxyConnector(String resourceString) {
        this.resourceString = resourceString;
        this.simpleConnector = new SimpleConnector(resourceString);
        this.securityCheckerImpl = new SecurityCheckerImpl();
    }

    @Override
    public void connect() {
        if (securityCheckerImpl.performSecurityCheck())
            simpleConnector.connect();
    }
}
