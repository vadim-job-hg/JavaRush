package com.javarush.task.task37.task3702;

/**
 * Created by Olaf on 22.03.2017.
 */
public interface Human {
}
