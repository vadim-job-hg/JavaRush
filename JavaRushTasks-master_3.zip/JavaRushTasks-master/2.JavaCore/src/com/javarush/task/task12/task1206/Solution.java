package com.javarush.task.task12.task1206;

/* 
print(int) и print(String)
Написать два метода: print(int) и print(String).
*/

public class Solution {
    public static void main(String[] args) {

    }

    //Напишите тут ваши методы
    public static void print (int a) {
        System.out.println(a);
    }

    public static void print (String s) {
        System.out.println(s);
    }
}
