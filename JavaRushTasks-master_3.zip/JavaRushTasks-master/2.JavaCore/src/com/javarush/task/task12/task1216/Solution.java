package com.javarush.task.task12.task1216;

/* 
Интерфейс Fly
Напиши свой public интерфейс Fly(летать).
Добавь в него два метода.
*/

public class Solution {
    public static void main(String[] args) {

    }

    //add an interface here - добавь интерфейс тут
    public interface Fly {
        int left ();
        int right ();
    }

}
