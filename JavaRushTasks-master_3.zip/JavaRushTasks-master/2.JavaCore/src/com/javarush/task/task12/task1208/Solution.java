package com.javarush.task.task12.task1208;

/* 
Пять методов print с разными параметрами
Написать пять методов print с разными параметрами.
*/

public class Solution {
    public static void main(String[] args) {

    }

    //Напишите тут ваши методы
    public static void print (int a) {
        System.out.println(a);
    }

    public static void print (char ch) {
        System.out.println(ch);
    }
    public static void print (Integer a) {
        System.out.println(a);
    }

    public static void print (String s) {
        System.out.println(s);
    }
    public static void print (float f) {
        System.out.println(f);
    }


}
