package com.javarush.task.task16.task1631.common;

/**
 * Created by Alexey on 14.03.2017.
 */
public class BmpReader implements ImageReader {
}
