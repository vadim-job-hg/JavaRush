package com.javarush.task.task16.task1631.common;

public enum ImageTypes {
    BMP,
    JPG,
    PNG
}
