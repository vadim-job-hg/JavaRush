package com.javarush.task.task16.task1632;

public interface Message {
    void showWarning();
}
