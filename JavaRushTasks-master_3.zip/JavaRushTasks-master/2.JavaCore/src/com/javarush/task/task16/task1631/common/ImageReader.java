package com.javarush.task.task16.task1631.common;

public interface ImageReader {
}
