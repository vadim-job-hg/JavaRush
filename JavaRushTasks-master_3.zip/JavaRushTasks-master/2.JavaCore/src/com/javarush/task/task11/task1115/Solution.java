package com.javarush.task.task11.task1115;

/* 
От школьника к рабству
Изменить четыре класса: Schoolboy (школьник), Student (студент), Worker (Сотрудник), Slave (Раб).
Унаследовать студента от школьника, сотрудника от студента, раба от сотрудника.
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Schoolboy {

    }

    public class Student extends Schoolboy{

    }

    public class Worker extends Student{

    }

    public class Slave extends Worker{

    }

}
