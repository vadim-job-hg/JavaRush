package com.javarush.task.task11.task1122;

/* 
Нужно добавить в программу новую функциональность
Добавь общий базовый класс ChessFigure к классам-фигур: (фигуры из шахмат).
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class King extends ChessFigure {
    }

    public class Queen extends ChessFigure {
    }

    public class Rook extends ChessFigure {
    }

    public class Knight extends ChessFigure {
    }

    public class Bishop extends ChessFigure {
    }

    public class Pawn extends ChessFigure {
    }

    public class ChessFigure {

    }
}
