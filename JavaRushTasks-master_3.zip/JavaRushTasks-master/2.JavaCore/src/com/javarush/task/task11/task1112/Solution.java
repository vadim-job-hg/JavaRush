package com.javarush.task.task11.task1112;

/* 
AppleIPhone и SamsungGalaxyS2
Изменить два класса AppleIPhone и SamsungGalaxyS2.
Унаследовать SamsungGalaxyS2 от AppleIPhone.
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class AppleIPhone {

    }

    public class SamsungGalaxyS2 extends AppleIPhone{

    }
}
