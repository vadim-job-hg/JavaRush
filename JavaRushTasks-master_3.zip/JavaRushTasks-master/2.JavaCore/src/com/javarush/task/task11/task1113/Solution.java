package com.javarush.task.task11.task1113;

/* 
Эволюция
Изменить четыре класса: Fish (Рыба), Animal (Животное), Ape (Обезьяна), Human (Человек).
Унаследовать животное от рыбы, обезьяну от животного и человека от обезьяны.
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Fish {

    }

    public class Animal extends Fish{

    }

    public class Ape extends Animal{

    }

    public class Human extends Ape{

    }

}
