package com.javarush.task.task11.task1121;

/* 
Нужно исправить программу, чтобы компилировалась и работала
Исправь наследование в классах: (классы Cat, Dog, Pet, House, Airplane).
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Pet {

    }

    public class Cat extends Pet {

    }

    public class Dog extends Pet {

    }

    public class House {

    }

    public class Airplane {

    }
}
