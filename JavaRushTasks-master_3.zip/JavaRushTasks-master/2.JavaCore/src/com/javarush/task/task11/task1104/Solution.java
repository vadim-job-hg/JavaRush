package com.javarush.task.task11.task1104;

/* 
Все мы работники
Написать четыре класса: Employee (сотрудник), Manager (управляющий), Chief (директор) и Secretary (секретарь).
Унаследовать управляющего, директора и секретаря от сотрудника.
*/

public class Solution {
    public static void main(String[] args) {
    }

    public class Manager extends Employee{

    }

    public class Chief extends Employee{

    }

    public class Employee {

    }

    public class Secretary extends Employee {

    }
}
