package com.javarush.task.task11.task1111;

/* 
Адам и Ева
Изменить два класса Adam (Адам) и Eve (Ева).
Унаследовать Еву от Адама.
*/

public class Solution {
    public static void main(String[] args) {
    }

    //Адам
    public class Adam {

    }

    //Ева
    public class Eve extends Adam{

    }
}
