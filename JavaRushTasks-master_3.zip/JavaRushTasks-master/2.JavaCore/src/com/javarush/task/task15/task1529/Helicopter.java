package com.javarush.task.task15.task1529;

/**
 * Created by Alexey on 14.03.2017.
 */
public class Helicopter implements Flyable {
}
