package com.javarush.task.task15.task1523;

/**
 * Created by Alexey on 13.03.2017.
 */
public class SubSolution extends Solution {
    public SubSolution() {
    }

    protected SubSolution(int i) {
        super(i);
    }

    SubSolution(double d) {
        super(d);
    }
}
