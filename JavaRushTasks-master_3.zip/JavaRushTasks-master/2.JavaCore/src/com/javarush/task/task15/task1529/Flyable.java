package com.javarush.task.task15.task1529;

public interface Flyable {
}
