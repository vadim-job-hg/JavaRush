package com.javarush.task.task15.task1525;

public class Statics {
    public static String FILE_NAME = "d://2016.txt";/* add your path to source file here*/;
}
