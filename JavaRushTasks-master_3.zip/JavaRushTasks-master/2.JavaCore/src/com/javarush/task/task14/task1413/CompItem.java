package com.javarush.task.task14.task1413;

/**
 * Created by Alexey on 12.03.2017.
 */
public interface CompItem {
    String getName();
}
