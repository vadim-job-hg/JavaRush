package com.javarush.task.task14.task1409;

/**
 * Created by Alexey on 11.03.2017.
 */
public class SuspensionBridge implements Bridge {
    @Override
    public int getCarsCount() {
        return 10;
    }
}
