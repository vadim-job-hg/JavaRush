package com.javarush.task.task14.task1409;

/**
 * Created by Alexey on 11.03.2017.
 */
public interface Bridge {
    int getCarsCount();
}
