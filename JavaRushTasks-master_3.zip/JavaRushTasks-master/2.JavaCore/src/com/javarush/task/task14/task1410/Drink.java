package com.javarush.task.task14.task1410;

/**
 * Created by Alexey on 12.03.2017.
 */
public abstract class Drink {
    public void taste() {
        System.out.println("Вкусно");

    }
}
