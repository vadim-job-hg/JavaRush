package com.javarush.task.task14.task1410;

/**
 * Created by Alexey on 12.03.2017.
 */
public class Wine extends Drink {
    public String getHolidayName() {
        return "День Рождения";
    }
}
