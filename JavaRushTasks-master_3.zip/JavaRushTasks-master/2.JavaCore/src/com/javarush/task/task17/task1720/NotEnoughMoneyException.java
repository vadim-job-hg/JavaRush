package com.javarush.task.task17.task1720;

public class NotEnoughMoneyException extends Exception {
}
