package com.javarush.task.task13.task1328;

public interface Defensable {
    BodyPart defense();
}
