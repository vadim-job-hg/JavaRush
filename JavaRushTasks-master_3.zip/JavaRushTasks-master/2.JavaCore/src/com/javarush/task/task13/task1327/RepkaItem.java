package com.javarush.task.task13.task1327;

public interface RepkaItem {
    public String getNamePadezh();
}
