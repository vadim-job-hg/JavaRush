package com.javarush.task.task13.task1317;

public interface WeatherType {
    String CLOUDY = "Cloudy";
    String FOGGY = "Foggy";
    String FROZEN = "Frozen";
}
