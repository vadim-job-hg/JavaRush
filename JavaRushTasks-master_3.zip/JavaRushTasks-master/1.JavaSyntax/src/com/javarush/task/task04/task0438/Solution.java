package com.javarush.task.task04.task0438;

/* 
Рисуем линии
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        //напишите тут ваш код
        for (int i=0;i<10;i++){
            System.out.print(8);
        }

        for (int i=0;i<10;i++){
            System.out.println(8);
        }


//        for(int a = 1; a<=10; a++){
//            System.out.print("8");
//        }
//        for(int a = 1; a<=10; a++) {
//            System.out.println("8");
//        }
    }
}
