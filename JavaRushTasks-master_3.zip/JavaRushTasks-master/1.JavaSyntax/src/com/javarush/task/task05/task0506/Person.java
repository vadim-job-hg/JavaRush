package com.javarush.task.task05.task0506;

/* 
Человечки
*/

//Создать class Person.  int age, адрес String address, пол char sex.

public class Person {
    //напишите тут ваш код
    public String name;
    public int age;
    public String address;
    public char sex;

    public Person (){
        this.name = "";
        this.age = 0;
        this.address = "";
        this.sex = 'M';
    }

    public static void main(String[] args) {

    }
}
