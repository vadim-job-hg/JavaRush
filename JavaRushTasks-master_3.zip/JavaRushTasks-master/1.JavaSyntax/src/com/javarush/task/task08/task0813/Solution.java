package com.javarush.task.task08.task0813;

import java.util.HashSet;

/* 
20 слов на букву «Л»
*/

public class Solution {
    public static HashSet<String> createSet() {
        //напишите тут ваш код
        HashSet <String> hs = new HashSet<>();
        hs.add("Лес");
        hs.add("Ложка");
        hs.add("Лань");
        hs.add("Лен");
        hs.add("Лук");
        hs.add("Лупа");
        hs.add("Лемур");
        hs.add("Лут");
        hs.add("Лоб");
        hs.add("Люк");
        hs.add("Лещь");
        hs.add("Лак");
        hs.add("Лик");
        hs.add("Лицо");
        hs.add("Липа");
        hs.add("Лось");
        hs.add("Лампа");
        hs.add("Листва");
        hs.add("Лакомка");
        hs.add("Лесовоз");

        return hs;
    }

    public static void main(String[] args) {

    }
}
