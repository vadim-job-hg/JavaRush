package com.javarush.task.task08.task0811;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/* 
Квартет «Методы»
*/

public class Solution {
    public static List getListForGet() {
        //напишите тут ваш код
        ArrayList lst = new ArrayList();
        return lst;
    }

    public static List getListForSet() {
        //напишите тут ваш код
        ArrayList lst = new ArrayList();
        return lst;
    }

    public static List getListForAddOrInsert() {
        //напишите тут ваш код
        LinkedList lst = new LinkedList<>();
        return lst;
    }

    public static List getListForRemove() {
        //напишите тут ваш код
        LinkedList lst = new LinkedList<>();
        return lst;
    }

    public static void main(String[] args) {

    }
}
