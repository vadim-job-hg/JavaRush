package com.javarush.task.task08.task0807;

import java.util.*;

/* 
LinkedList и ArrayList
*/

public class Solution {
    public static Object createArrayList() {
        //напишите тут ваш код
        ArrayList lst = new ArrayList();
        return lst;
    }

    public static Object createLinkedList() {
        //напишите тут ваш код
        LinkedList lst = new LinkedList();
        return lst;
    }

    public static void main(String[] args) {

    }
}
