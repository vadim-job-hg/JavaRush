package com.javarush.task.task06.task0618;

/* 
KissMyShinyMetalAss
*/

public class Solution {
    public static class KissMyShinyMetalAss {

    }

    public static void main(String[] args) {
        //напишите тут ваш код
        KissMyShinyMetalAss km = new KissMyShinyMetalAss();

        System.out.println(km);
    }
}
