package com.javarush.task.task03.task0309;

/* 
Сумма 10 чисел
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        int summa = 0;
        for (int i=1;i<11;i++){
            summa += i;
            System.out.println(summa);
        }
    }
}
