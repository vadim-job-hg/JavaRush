package com.javarush.task.task03.task0313;

/* 
Мама мыла раму
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код

        System.out.println("МылаРамуМама");
        System.out.println("МылаМамаРаму");
        System.out.println("РамуМылаМама");
        System.out.println("РамуМамаМыла");
        System.out.println("МамаРамуМыла");
        System.out.println("МамаМылаРаму");

    }
}
