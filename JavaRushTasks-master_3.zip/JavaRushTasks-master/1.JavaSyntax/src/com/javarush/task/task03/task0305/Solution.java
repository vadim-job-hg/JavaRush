package com.javarush.task.task03.task0305;

/* 
Я так давно родился
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println("APRIL 6 1977");
    }
}
