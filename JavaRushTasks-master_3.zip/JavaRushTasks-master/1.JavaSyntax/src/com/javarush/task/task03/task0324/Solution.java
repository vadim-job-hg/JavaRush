package com.javarush.task.task03.task0324;

/* 
Меркантильные намерения
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        int i=0;
        while (i<10) {
            System.out.println("Я хочу большую зарплату, и для этого изучаю Java");
            i++;
        }
    }
}
