package com.javarush.task.task03.task0302;

/* 
Немедленно в печать
*/
public class Solution {
    //напишите тут ваш код

    public static void main(String[] args) {
        printString("Hello Amigo!");
    }

    public static void printString (String s) {
        System.out.println(s);
    }
}
