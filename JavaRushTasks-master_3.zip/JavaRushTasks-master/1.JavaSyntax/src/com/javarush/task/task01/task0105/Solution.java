package com.javarush.task.task01.task0105;

/* 
Объявляем переменные
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        String name;
        int age;
        String city;
    }
}
