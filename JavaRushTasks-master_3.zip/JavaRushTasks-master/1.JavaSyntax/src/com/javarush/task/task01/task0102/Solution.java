package com.javarush.task.task01.task0102;

/* 
Комплимент учителю
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println ("Элли самая красивая");
        System.out.println ("Элли самая красивая");
        System.out.println ("Элли самая красивая");
        System.out.println ("Элли самая красивая");
        System.out.println ("Элли самая красивая");
    }
}
