package com.javarush.task.task01.task0103;

/* 
Мой юный друг
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println(3126-8);
    }
}
